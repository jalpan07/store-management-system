# Store-Management-System

Open the Sample Dataset.py and replace the mysql server details with accordingly before running. Then run this file to create the tables and insert some sample data in the database.<br>
Open the Main.py and replace the mysql server details with accordingly before running. Then run the file. The GUI interface will pop up and the functionalities are ready to use.
